# Clock App
Run: python app.py
